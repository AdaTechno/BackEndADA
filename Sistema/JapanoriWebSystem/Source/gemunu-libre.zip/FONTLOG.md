FONTLOG for Gemunu Libre
-------------------

This file provides detailed information on the Gemunu Libre font software.
This information should be distributed along with the Gemunu Libre fonts and any derivative works.

Please see https://github.com/mooniak/gemunu-libre-font for documentation,development plans, contribution guidelines and all past releases.


ChangeLog
----------
6 April 2016 (mooniak) Gemunu Libre v1.001

- Minor feature fixes

4 April 2016 (mooniak) Gemunu Libre v1.000

- Added new medium weight
- TTF build system, this release
- Minor updates

29 February 2016 (mooniak) Gemunu Libre Initial Release v0.900

- Full Sinhala Coverage
- Full Adobe Latin 3 coverage


Information for Contributors
------------------------------

Gemunu Libre Font is released under the OFL 1.1 - http://scripts.sil.org/OFL

For information on what you're allowed to change or modify, consult the
OFL-1.1.txt and OFL-FAQ.txt files. The OFL-FAQ also gives a very general
rationale and various recommendations regarding why you would want to
contribute to the project or make your own version of the font.

See the project website for the current trunk and the various branches:

http://mooniak.com/gemunu-libre-font
